@echo off
cd /d "%~dp0"
set "SF=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\WA Sender.cmd"
> "%SF%" echo @echo off
>> "%SF%" echo start "WA Sender" /min cmd /c ""%~dp0start.bat" auto"
echo Done. WA Sender will now start automatically when you sign in to Windows.
echo To undo, run remove-autostart.bat
pause
