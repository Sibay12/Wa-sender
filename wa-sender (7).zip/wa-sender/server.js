require('dotenv').config();
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const XLSX = require('xlsx');
const QRCode = require('qrcode');

const PORT = process.env.PORT || 3000;
const DEFAULT_CC = process.env.DEFAULT_COUNTRY_CODE || '91';
const MIN_DELAY = Number(process.env.MIN_DELAY_SEC || 20);
const MAX_DELAY = Number(process.env.MAX_DELAY_SEC || 45);
const AUTH_USER = process.env.AUTH_USER;
const AUTH_PASS = process.env.AUTH_PASS;
const AUTH_ON = !!(AUTH_USER && AUTH_PASS);
if (process.env.RENDER && !AUTH_ON) { console.error('AUTH_USER and AUTH_PASS are required on Render'); process.exit(1); }
process.on('unhandledRejection', (e) => console.error('Unhandled rejection:', e && e.message));
process.on('uncaughtException', (e) => console.error('Uncaught exception:', e && e.stack));

const app = express();
app.set('trust proxy', 1);
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024 } });
app.use(express.json());
const started = Date.now();
const SESSION_DIR = process.env.SESSION_PATH || './session';
const MAX_ROWS = Number(process.env.MAX_ROWS || 500);
const AUTH_DIR = path.join(SESSION_DIR, 'baileys');
const LINKED_FLAG = path.join(SESSION_DIR, '.linked-baileys');
const hasSession = () => fs.existsSync(LINKED_FLAG);
let lastActivity = Date.now();
function memInfo() {
  const rd = (p) => { try { const v = Number(fs.readFileSync(p, 'utf8').trim()); return isFinite(v) ? v : null; } catch (e) { return null; } };
  const used = rd('/sys/fs/cgroup/memory.current') ?? rd('/sys/fs/cgroup/memory/memory.usage_in_bytes');
  const lim = rd('/sys/fs/cgroup/memory.max') ?? rd('/sys/fs/cgroup/memory/memory.limit_in_bytes');
  const mb = (v) => (v && v < 1e13 ? Math.round(v / 1048576) : null);
  return { used_mb: mb(used), limit_mb: mb(lim) };
}

// ---------- Health check (public, used by uptime pingers) ----------
app.get('/health', (req, res) => res.json({ status: 'ok', whatsapp: wa.status, uptime_sec: Math.floor((Date.now() - started) / 1000), memory: memInfo() }));

// ---------- Login (cookie session) ----------
const sign = (v) => crypto.createHmac('sha256', process.env.SESSION_SECRET || AUTH_PASS || 'dev').update(v).digest('hex');
const hash = (v) => crypto.createHash('sha256').update(String(v)).digest();
const same = (a, b) => crypto.timingSafeEqual(hash(a), hash(b));
const makeToken = () => { const exp = String(Date.now() + 30 * 864e5); return exp + '.' + sign(exp); };
function validToken(t) {
  if (!t) return false;
  const [exp, sig] = t.split('.');
  return !!(exp && sig && Number(exp) > Date.now() && same(sig, sign(exp)));
}
function getCookie(req, name) {
  const m = (req.headers.cookie || '').split(';').map((s) => s.trim()).find((s) => s.startsWith(name + '='));
  return m ? decodeURIComponent(m.slice(name.length + 1)) : null;
}
const loggedIn = (req) => !AUTH_ON || validToken(getCookie(req, 'session'));
const attempts = new Map();

app.post('/api/login', (req, res) => {
  const a = attempts.get(req.ip) || { n: 0, until: 0 };
  if (a.until > Date.now()) return res.status(429).json({ error: 'Too many attempts. Try again in a few minutes.' });
  const { username = '', password = '' } = req.body || {};
  if (AUTH_ON && same(username, AUTH_USER) && same(password, AUTH_PASS)) {
    attempts.delete(req.ip);
    const secure = req.secure || req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
    res.setHeader('Set-Cookie', `session=${makeToken()}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${secure}`);
    return res.json({ ok: true });
  }
  a.n++; if (a.n >= 5) { a.until = Date.now() + 10 * 60 * 1000; a.n = 0; }
  attempts.set(req.ip, a);
  res.status(401).json({ error: 'Incorrect username or password.' });
});
app.post('/api/logout', (req, res) => {
  res.setHeader('Set-Cookie', 'session=; HttpOnly; Path=/; Max-Age=0');
  res.json({ ok: true });
});
app.get('/login', (req, res) => loggedIn(req) ? res.redirect('/') : res.sendFile(path.join(__dirname, 'public', 'login.html')));

app.use((req, res, next) => {
  if (loggedIn(req)) return next();
  if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Please log in.' });
  res.redirect('/login');
});
app.use(express.static(path.join(__dirname, 'public')));

// ---------- WhatsApp connection (Baileys: no browser, very low memory) ----------
const wa = { status: 'stopped', qr: null, info: null, error: null };
const silent = { level: 'silent', child: () => silent, trace() {}, debug() {}, info() {}, warn() {}, error() {}, fatal() {} };
let sock = null, connecting = false, manualStop = false, fails = 0, B = null;

async function connect() {
  if (sock || connecting) return;
  connecting = true; manualStop = false; wa.status = 'starting'; wa.error = null; wa.qr = null;
  try {
    B = B || (await import('@whiskeysockets/baileys'));
    const pick = (k) => B[k] ?? (B.default && B.default[k]);
    const make = typeof B.default === 'function' ? B.default : B.default.default;
    const { state, saveCreds } = await pick('useMultiFileAuthState')(AUTH_DIR);
    let version;
    try { version = (await (pick('fetchLatestBaileysVersion') || pick('fetchLatestWaWebVersion'))()).version; } catch (e) {}
    const s = make({
      auth: state, version, logger: silent, browser: ['WA Sender', 'Chrome', '1.0'],
      printQRInTerminal: false, syncFullHistory: false, markOnlineOnConnect: false,
      generateHighQualityLinkPreview: false, shouldSyncHistoryMessage: () => false
    });
    sock = s;
    s.ev.on('creds.update', saveCreds);
    s.ev.on('connection.update', async (u) => {
      if (sock !== s) return;
      const { connection, lastDisconnect, qr } = u;
      if (qr) { fails = 0; wa.status = 'qr'; wa.qr = await QRCode.toDataURL(qr, { margin: 1, width: 300 }); }
      if (connection === 'open') {
        fails = 0; wa.status = 'ready'; wa.qr = null; wa.error = null;
        wa.info = String((s.user && s.user.id) || '').split(':')[0].split('@')[0] || null;
        try { fs.mkdirSync(SESSION_DIR, { recursive: true }); fs.writeFileSync(LINKED_FLAG, '1'); } catch (e) {}
      }
      if (connection === 'close') {
        const err = lastDisconnect && lastDisconnect.error;
        const code = err && err.output && err.output.statusCode;
        sock = null; wa.qr = null; wa.info = null;
        try { s.end(undefined); } catch (e) {}
        if (code === 401) {
          fs.rmSync(LINKED_FLAG, { force: true }); fs.rmSync(AUTH_DIR, { recursive: true, force: true });
          wa.status = 'stopped'; wa.error = 'Logged out from the phone. Click Connect to link again.'; return;
        }
        if (code === 440) { wa.status = 'stopped'; wa.error = 'This session was opened on another device.'; return; }
        if (manualStop) { wa.status = 'stopped'; return; }
        if (++fails > 6) { wa.status = 'stopped'; wa.error = 'Could not connect (code ' + code + '). Try again in a few minutes.'; return; }
        wa.status = 'starting'; setTimeout(connect, code === 515 ? 500 : 3000);
      }
    });
  } catch (e) {
    sock = null; wa.status = 'stopped'; wa.error = 'Could not start WhatsApp: ' + e.message;
  }
  connecting = false;
}
async function disconnect(unlink) {
  manualStop = true;
  const s = sock; sock = null;
  wa.status = 'stopped'; wa.qr = null; wa.info = null; wa.error = null;
  try { if (s) { if (unlink) await s.logout(); else s.end(undefined); } } catch (e) {}
  if (unlink) { fs.rmSync(LINKED_FLAG, { force: true }); fs.rmSync(AUTH_DIR, { recursive: true, force: true }); }
}

// ---------- Sending job ----------
let job = { running: false, stop: false, rows: [] };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const norm = (k) => String(k).trim().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');

function cleanPhone(raw) {
  let d = String(raw || '').replace(/\D/g, '');
  if (d.length === 11 && d.startsWith('0')) d = d.slice(1);
  if (d.length === 10) d = DEFAULT_CC + d;
  return d.length >= 11 && d.length <= 15 ? d : null;
}
function fill(template, data) {
  let missing = null;
  const text = template.replace(/\{(\w+)\}/g, (m, key) => {
    const v = data[key.toLowerCase()];
    if (v === undefined || v === '') { missing = key; return m; }
    return v;
  });
  return { text, missing };
}
async function waitReady() {
  if (wa.status !== 'ready') connect();
  const end = Date.now() + 180000;
  while (Date.now() < end && !job.stop) {
    if (wa.status === 'ready') return true;
    if (wa.status === 'qr' || wa.status === 'stopped') return false;
    await sleep(2000);
  }
  return false;
}
async function runJob() {
  job.running = true; job.stop = false;
  if (!(await waitReady())) {
    if (!job.stop) job.rows.forEach((r) => { if (r.status === 'pending') { r.status = 'failed'; r.error = 'Could not connect to WhatsApp. Click Connect and scan the QR code.'; } });
    job.running = false; return;
  }
  for (const row of job.rows) {
    if (job.stop) break;
    if (row.status !== 'pending') continue;
    try {
      if (!sock || wa.status !== 'ready') throw new Error('WhatsApp is not connected');
      const [found] = (await sock.onWhatsApp(row.phone + '@s.whatsapp.net')) || [];
      if (!found || !found.exists) throw new Error('Number is not on WhatsApp');
      await sock.sendMessage(found.jid, { text: row.message });
      row.status = 'sent';
    } catch (e) { row.status = 'failed'; row.error = e.message; }
    if (!job.stop && job.rows.some((r) => r.status === 'pending')) {
      await sleep((MIN_DELAY + Math.random() * (MAX_DELAY - MIN_DELAY)) * 1000);
    }
  }
  job.running = false; lastActivity = Date.now();
}

// ---------- API ----------
app.get('/api/status', (req, res) => {
  const counts = { sent: 0, failed: 0, pending: 0 };
  job.rows.forEach((r) => counts[r.status]++);
  res.json({ wa: { ...wa, linked: hasSession() }, running: job.running, counts, rows: job.rows.map(({ name, phone, status, error }) => ({ name, phone, status, error })), uptime: Math.floor((Date.now() - started) / 1000), lan: lanUrls() });
});
app.post('/api/connect', (req, res) => { connect(); res.json({ ok: true }); });
app.post('/api/disconnect', async (req, res) => { await disconnect(!!(req.body && req.body.unlink)); res.json({ ok: true }); });
app.post('/api/stop', (req, res) => { job.stop = true; res.json({ ok: true }); });
app.post('/api/clear', (req, res) => { if (!job.running) job.rows = []; res.json({ ok: true }); });

app.post('/api/start', upload.single('file'), (req, res) => {
  if (job.running) return res.status(400).json({ error: 'A job is already running.' });
  if (wa.status !== 'ready' && !hasSession()) return res.status(400).json({ error: 'Click Connect and scan the QR code first.' });
  if (!req.file) return res.status(400).json({ error: 'Please choose an Excel file.' });
  const template = (req.body.template || '').trim();
  if (!template) return res.status(400).json({ error: 'Please write a message.' });

  let raw;
  try {
    const wb = XLSX.read(req.file.buffer, { type: 'buffer', sheetRows: MAX_ROWS + 1 });
    raw = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: '' });
  } catch (e) { return res.status(400).json({ error: 'Could not read the file. Use .xlsx, .xls or .csv.' }); }
  const rows = raw.map((r) => { const d = {}; Object.keys(r).forEach((k) => (d[norm(k)] = String(r[k]).trim())); return d; });
  if (!rows.length) return res.status(400).json({ error: 'The file is empty.' });

  const keys = Object.keys(rows[0]);
  const nameKey = keys.find((k) => k.includes('business')) || keys.find((k) => k.includes('name'));
  const phoneKey = keys.find((k) => /mobile|phone|number|whatsapp/.test(k));
  if (!nameKey || !phoneKey) return res.status(400).json({ error: 'Columns required: Business Name and Mobile Number.' });

  const seen = new Set();
  job.rows = rows.map((data) => {
    data.business_name = data[nameKey];
    const phone = cleanPhone(data[phoneKey]);
    const base = { name: data.business_name, phone: phone || data[phoneKey], status: 'pending', error: '' };
    if (!phone) return { ...base, status: 'failed', error: 'Invalid number' };
    if (seen.has(phone)) return { ...base, status: 'failed', error: 'Duplicate number' };
    seen.add(phone);
    const { text, missing } = fill(template, data);
    if (missing) return { ...base, status: 'failed', error: `Column "${missing}" not found in file` };
    return { ...base, phone, message: text };
  });
  runJob();
  res.json({ ok: true, total: job.rows.length });
});

// ---------- Keep-alive: ping own /health (set PUBLIC_URL, or Render sets RENDER_EXTERNAL_URL) ----------
const PUBLIC_URL = process.env.PUBLIC_URL || process.env.RENDER_EXTERNAL_URL;
if (PUBLIC_URL) setInterval(() => fetch(PUBLIC_URL.replace(/\/$/, '') + '/health').catch(() => {}), 10 * 60 * 1000);

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
  if (hasSession()) connect();
  console.log('\n  Open on this PC:        http://localhost:' + PORT);
  console.log('  Open from other devices: ' + lanUrls().join('   ') + '\n');
});

// ---------- Logs: status changes + memory every minute ----------
let lastStatus = '';
setInterval(() => { if (wa.status !== lastStatus) { lastStatus = wa.status; console.log('WhatsApp status:', wa.status, wa.error || ''); } }, 3000);
setInterval(() => { const m = memInfo(); console.log(`[mem] container ${m.used_mb || '-'}MB / ${m.limit_mb || '?'}MB, node rss ${Math.round(process.memoryUsage().rss / 1048576)}MB`); }, 60000);
