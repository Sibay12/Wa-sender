@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title WA Sender
set "AUTO=%~1"

where node >nul 2>&1
if %errorlevel%==0 goto have_node
echo Node.js not found. Installing it automatically...
where winget >nul 2>&1
if not %errorlevel%==0 goto no_winget
winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
set "PATH=%PATH%;%ProgramFiles%\nodejs"
where node >nul 2>&1
if %errorlevel%==0 goto have_node
echo Node.js was installed. Please CLOSE this window and run start.bat again.
pause
exit /b 1

:no_winget
echo Could not install Node.js automatically.
echo Install the LTS version from https://nodejs.org and run start.bat again.
pause
exit /b 1

:have_node
if exist .env goto have_env
echo.
echo ===== First-time setup =====
set "WA_USER=admin"
set /p "WA_USER=Choose a login username (press Enter for admin): "
set "WA_PASS="
:ask_pass
set /p "WA_PASS=Choose a login password (letters and numbers only): "
if "!WA_PASS!"=="" goto ask_pass
(
echo AUTH_USER=!WA_USER!
echo AUTH_PASS=!WA_PASS!
echo SESSION_SECRET=%RANDOM%%RANDOM%%RANDOM%%RANDOM%%RANDOM%%RANDOM%
echo SESSION_PATH=./session
echo DEFAULT_COUNTRY_CODE=91
echo MIN_DELAY_SEC=20
echo MAX_DELAY_SEC=45
echo MAX_ROWS=500
echo PORT=3000
) > .env
echo Saved. You can edit .env later.

:have_env
if exist node_modules goto have_modules
where git >nul 2>&1
if %errorlevel%==0 goto have_git
echo Installing Git, needed by one WhatsApp package...
winget install -e --id Git.Git --accept-package-agreements --accept-source-agreements
set "PATH=%PATH%;%ProgramFiles%\Git\cmd"
:have_git
echo.
echo Installing required packages. First time only, this can take a few minutes...
call npm install --no-audit --no-fund
if not %errorlevel%==0 goto npm_fail
goto have_modules

:npm_fail
echo.
echo Package install failed. Check your internet connection and run start.bat again.
pause
exit /b 1

:have_modules
netsh advfirewall firewall show rule name="WA Sender" >nul 2>&1
if %errorlevel%==0 goto fw_done
netsh advfirewall firewall add rule name="WA Sender" dir=in action=allow protocol=TCP localport=3000 >nul 2>&1
:fw_done

if /i "%AUTO%"=="auto" goto run
start "" http://localhost:3000

:run
echo.
echo Starting WA Sender. Keep this window open.
echo If Windows asks about the firewall, click "Allow access".
start "WA Sender" /low /b /wait node --max-old-space-size=128 server.js
echo.
echo Server stopped. Restarting in 5 seconds. Close this window to quit.
timeout /t 5 /nobreak >nul
goto run
