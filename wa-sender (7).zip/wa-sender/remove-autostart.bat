@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\WA Sender.cmd" >nul 2>&1
echo Auto-start removed.
pause
