# WA Sender (Windows quick start, lightweight)

Uses no browser, so it needs only about 100 MB of RAM (works on a 2 GB PC). If you used an older version, unzip this into a NEW folder and scan the QR code again.

1. Unzip the folder anywhere.
2. Double-click **start.bat** (or run it from Command Prompt).
   - It installs Node.js and all packages automatically if missing.
   - First run asks you to choose a login username and password.
3. The browser opens. Click **Connect** and scan the QR code once.
4. The console prints addresses like `http://192.168.1.25:3000`. Open that address on any phone or PC on the same Wi-Fi.

## Run automatically
- Double-click **install-autostart.bat**: starts WA Sender whenever you sign in to Windows. Undo with **remove-autostart.bat**.
- start.bat restarts the server by itself if it crashes.
- Set Windows power settings so the PC never sleeps while plugged in.
- Tip: in your router, reserve a fixed IP for this PC so the address never changes. The PC name address (`http://PCNAME:3000`) also works on many networks.

## Excel format
Columns: Business Name, Mobile Number, optional Rating (or any extra column used as `{column_name}`). See demo_contacts.xlsx.

## Settings
Edit `.env` (see `.env.example`). Login stays valid for 30 days on each device.

## Safety
Test on your own numbers first. Do not message more than 30-50 new numbers per day to avoid a WhatsApp ban.
Anyone on your Wi-Fi who knows the password can use the app, so keep the password private.

## Deploy on Render (optional)
Docker runtime, Disk at `/data`, env vars from `.env.example`, Health Check Path `/health`.
